from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("SSH OPNVPN", "ssh")],
                    [Button.inline("XRAY VMESS", "vmess-member"),
                     Button.inline("XRAY VLESS", "vless-member")],
                    [Button.inline("XRAY TRJAN", "trojan-member"),
                     Button.inline("XRAY SDWSK", "shadowsocks-member")],
                    [Button.inline("NOOBZ VPNS", "noobzvpn-member")],
                    [Button.url("TELE ADMIN", "https://t.me/Riswanvpnstore"),
                     Button.inline("TOP UP DISINI", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━**
** 🧑‍💻𝗦𝗲𝘄𝗮 𝗕𝗼𝘁 𝗣𝗮𝗻𝗲𝗹 𝗥𝗶𝘀𝘄𝗮𝗻𝗩𝗽𝗻 𝗦𝘁𝗼𝗿𝗲🧑‍💻 **
**━━━━━━━━━━━━━━━━━━━━━━━━**
**🙎‍♂️𝗜𝗱 𝘂𝘀𝗲𝗿👉** `{user_id}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
**💰𝗦𝗲𝘄𝗮 𝟭 𝗯𝘂𝗹𝗮𝗻 𝗥𝗽 ..𝟲𝟱.𝟬𝟬𝟬**
**💰𝗦𝗲𝘄𝗮 𝟮 𝗯𝘂𝗹𝗮𝗻 𝗥𝗽 𝟭𝟮𝟬.𝟬𝟬𝟬**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**✅𝗝𝗮𝗴𝗮𝗻 𝘁𝗮𝗸𝘂𝘁 𝗩𝗽𝘀 𝗸𝗮𝗺𝗶 𝘀𝘂𝘀𝗽𝗲𝗱**
**✅𝗞𝗮𝗿𝗻𝗮 𝗩𝗽𝘀 𝗸𝗮𝗺𝗶 𝘀𝘂𝗱𝗮𝗵 𝗮𝗺𝗮𝗻**
**✅𝗩𝗽𝘀 𝗽𝗮𝘆 𝗴𝗼 𝗩𝗽𝘀 𝗸𝗮𝗺𝗶 𝗧𝗲𝗿𝗮𝘄𝗮𝘁**

**📗𝗡𝗼𝘁𝗲𝘀, 𝗕𝗲𝗯𝗮𝘀 𝗷𝘂𝗮𝗹𝗮𝗻 𝗯𝗲𝗿𝗮𝗽𝗮𝗽𝘂𝗻**
**✅𝗧𝗲𝗿𝘀𝗲𝗿𝗮𝗵 𝗸𝗮𝗹𝗶𝗮𝗻**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**💰𝗦𝗶𝘀𝗮 𝘀𝗮𝗹𝗱𝗼 𝗺𝘂 : ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("SSH OPNVPN", "ssh"),
                    Button.inline("XRAY VMESS", "vmess"),
                     Button.inline("XRAY VLESS", "vless")],

                    [Button.inline("BUY SCRIPT", "trojan"),
                     Button.inline("XRAY SDWSK", "shadowsocks"),
                    Button.inline("NOOBZ VPNS", "noobzvpns")],

                     [Button.inline("ADD PANEL", "registrasi-member"),
                     Button.inline("DEL PANEL", "delete-member"),
                     Button.inline("LIST ID PANEL", "show-user")],

                    [Button.inline("ISI SALDO", "addsaldo"),
                    Button.inline("CEK INFO VPS", "info"),
                     Button.inline("SETINGS", "setting")],

                    [Button.url("TELEGRAM", "https://t.me/Riswanvpnstore"),
                     Button.url("MASUKAN IPVPS", "https://github.com/scriswan/lunaip/edit/main/ip")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━**
** 🧑‍💻𝗦𝗲𝘄𝗮 𝗕𝗼𝘁 𝗣𝗮𝗻𝗲𝗹 𝗥𝗶𝘀𝘄𝗮𝗻𝗩𝗽𝗻 𝗦𝘁𝗼𝗿𝗲🧑‍💻 **
**━━━━━━━━━━━━━━━━━━━━━━━━**
**🙎‍♂️𝗜𝗱 𝘂𝘀𝗲𝗿👉** `{user_id}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
**💰𝗦𝗲𝘄𝗮 𝟭 𝗯𝘂𝗹𝗮𝗻 𝗥𝗽 ..𝟲𝟱.𝟬𝟬𝟬**
**💰𝗦𝗲𝘄𝗮 𝟮 𝗯𝘂𝗹𝗮𝗻 𝗥𝗽 𝟭𝟮𝟬.𝟬𝟬𝟬**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**✅𝗝𝗮𝗴𝗮𝗻 𝘁𝗮𝗸𝘂𝘁 𝗩𝗽𝘀 𝗸𝗮𝗺𝗶 𝘀𝘂𝘀𝗽𝗲𝗱**
**✅𝗞𝗮𝗿𝗻𝗮 𝗩𝗽𝘀 𝗸𝗮𝗺𝗶 𝘀𝘂𝗱𝗮𝗵 𝗮𝗺𝗮𝗻**
**✅𝗩𝗽𝘀 𝗽𝗮𝘆 𝗴𝗼 𝗩𝗽𝘀 𝗸𝗮𝗺𝗶 𝗧𝗲𝗿𝗮𝘄𝗮𝘁**

**📗𝗡𝗼𝘁𝗲𝘀, 𝗕𝗲𝗯𝗮𝘀 𝗷𝘂𝗮𝗹𝗮𝗻 𝗯𝗲𝗿𝗮𝗽𝗮𝗽𝘂𝗻**
**✅𝗧𝗲𝗿𝘀𝗲𝗿𝗮𝗵 𝗸𝗮𝗹𝗶𝗮𝗻**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**🙎‍♂️𝗧𝗼𝘁𝗮𝗹 𝘂𝘀𝗲𝗿 𝗯𝗼𝘁 :** `{get_user_count()}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )



