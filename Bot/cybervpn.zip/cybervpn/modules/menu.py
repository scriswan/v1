from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("⚜️SSH OPNVPN⚜️", "ssh")],
                    [Button.inline("⚜️XRAY VMESS⚜️", "vmess-member"),
                     Button.inline("⚜️XRAY VLESS⚜️", "vless-member")],
                    [Button.inline("⚜️XRAY TORJAN⚜️", "trojan-member"),
                     Button.inline("⚜️XRAY SDWSK⚜️", "shadowsocks-member")],
                    [Button.inline("⚜️NOOBZ VPNS⚜️", "noobzvpn-member")],
                    [Button.url("🧑‍💻ADMIN🧑‍💻", "https://t.me/Riswanvpnstore"),
                     Button.inline("📩topup manual📩", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
          ** 🇲🇨Lesseler RiswanVpn🇲🇨 **
**━━━━━━━━━━━━━━━━━━━━━━━**
**» ⛔Your ID ** `{user_id}`
**» Harga lesseler hanya 6000**
**» Silahkan top up minimal 6000**
**» Jadi admin 1 Bulan harus top up**
**» Minimal 60k bisa untuk jualan**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» SISA SALDO MU: ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("⚜️SSH OPNVPN⚜️", "ssh")],
                    [Button.inline("⚜️XRAY VMESS⚜️", "vmess"),
                     Button.inline("⚜️XRAY VLESS⚜️", "vless")],
                    [Button.inline("⚜️SCRIPT R-T⚜️", "trojan"),
                     Button.inline("⚜️XRAY SDWSK⚜️", "shadowsocks")],
                    [Button.inline("⚜️NOOBVPN⚜️", "noobzvpns"),
                     Button.inline("⚜️ADD USER⚜️", "registrasi-member"),
                     Button.inline("⚜️DEL USER⚜️", "delete-member")],
                     [Button.inline("⚜️LISTE USER⚜️", "show-user")],
                    [Button.inline("⚜️ADD SALDO USER⚜️", "addsaldo")],
                    [Button.inline("⚜️Check Vps Info⚜️", "info"),
                     Button.inline("☠️ FEATUR SET ☠️", "setting")],
                    [Button.url("❗TELEGRAM❗", "https://t.me/Riswanvpnstore"),
                     Button.url("📩WHATSAPP📩", "https://wa.me/6285888801241")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
      ** 🇲🇨Script Riswan tunneling🇲🇨 **
**━━━━━━━━━━━━━━━━━━━━━━**     
**» ⛔Your ID ** `{user_id}`
**» Harga lesseler hanya 6000**
**» Silahkan top up minimal 6000**
**» Jadi admin 1 Bulan harus top up**
**» Minimal 60k bisa untuk jualan**
**━━━━━━━━━━━━━━━━━━━━━━**
**» Total user in :** `{get_user_count()}`
**━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

