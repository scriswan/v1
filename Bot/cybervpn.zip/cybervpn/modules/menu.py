from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("SSH OPNVPN LIBEV", "ssh")],
                    [Button.inline("XRAY VMESS LIBEV", "vmess-member"),
                     Button.inline("XRAY VLESS LIBEV", "vless-member")],
                    [Button.inline("XRAY TRJAN LIBEV", "trojan-member"),
                     Button.inline("XRAY SDWSK LIBEV", "shadowsocks-member")],
                    [Button.inline("NOOBZ VPNS LIBEV", "noobzvpn-member")],
                    [Button.url("❗TeLeGrAm❗", "https://t.me/Riswanvpnstoreing"),
                     Button.inline("📩topup manual📩", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━**
      ** 🇲🇨 RISWANVPN🇲🇨 **
**━━━━━━━━━━━━━━━━**
**» ⛔Your ID ** `{user_id}`
**» ⛔Harga SSH    IDR.10.000 **
**» ⛔Harga VMESS  IDR.15.000 **
**» ⛔Harga VLESS  IDR.15.000 **
**» ⛔Harga TROJAN IDR.15.000 **
**» ⛔Harga SDWSOK IDR.15.000 **
**» ⛔Harga NOOBZS IDR.15.000 **
**━━━━━━━━━━━━━━━━**
**» SISA SALDO MU: ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("SSH OPNVPN LIBEV", "ssh")],
                    [Button.inline("XRAY VMESS LIBEV", "vmess"),
                     Button.inline("XRAY VLESS LIBEV", "vless")],
                    [Button.inline("XRAY TRJAN LIBEV", "trojan"),
                     Button.inline("XRAY SDWSK LIBEV", "shadowsocks")],
                    [Button.inline("NOOBZ VPNS LIBEV", "noobzvpns"),
                     Button.inline("ADDED MEMBERS", "registrasi-member"),
                     Button.inline("DELET MEMBERS", "delete-member")],
                     [Button.inline("LISTE MEMBERS", "show-user")],
                    [Button.inline("ADD MEMBER SALDO", "addsaldo")],
                    [Button.inline("💢Check Vps Info💢", "info"),
                     Button.inline("☠️ FEATUR SET ☠️", "setting")],
                    [Button.url("❗TeLeGrAm❗", "https://t.me/Riswanvpnstore"),
                     Button.url("📩WHATSAPP📩", "https://wa.me/6285888801241")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━**
        ** 🇲🇨 RISWANVPN🇲🇨 **
**━━━━━━━━━━━━━━━━**
**» ⛔Your ID ** `{user_id}`
**» ⛔Harga SSH    IDR.10.000 **
**» ⛔Harga VMESS  IDR.10.000 **
**» ⛔Harga VLESS  IDR.10.000 **
**» ⛔Harga TROJAN IDR.10.000 **
**» ⛔Harga SDWSOK IDR.10.000 **
**» ⛔Harga NOOBZS IDR.10.000 **
**━━━━━━━━━━━━━━━━**
**» Total user in :** `{get_user_count()}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

