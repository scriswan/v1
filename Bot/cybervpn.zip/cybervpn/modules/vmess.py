#!/bin/bash
clear
red() { echo -e "\\033[32;1m${*}\\033[0m"; }
clear
#IZIN SCRIPT
MYIP=$(curl -sS ipv4.icanhazip.com)
echo -e "\e[32mloading...\e[0m"
clear
red() { echo -e "\\033[32;1m${*}\\033[0m"; }

# // Get Bot
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
export TIME="10"
export URL="https://api.telegram.org/bot$KEY/sendMessage"
clear

# Valid Script
ipsaya=$(curl -sS ipv4.icanhazip.com)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/Lite-VPN/izin/main/ip"
checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            \033[91;1mPERMISSION DENIED !\033[0m"
    echo -e "   \033[0;33mYour VPS\033[0m $ipsaya \033[0;33mHas been Banned\033[0m"
    echo -e "     \033[0;33mBuy access permissions for scripts\033[0m"
    echo -e "             \033[0;33mContact Admin :\033[0m"
    echo -e "      \033[2;32mWhatsApp\033[0m https://wa.me/6283867809137"
    echo -e "      \033[2;32mTelegram\033[0m https://t.me/LITE_VERMILION"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    sleep 10
	reboot
  fi
}
checking_sc
clear
export TIME="10"
IP=$(curl -sS ipv4.icanhazip.com)
ISP=$(cat /etc/xray/isp)
CITY=$(cat /etc/xray/city)
domain=$(cat /etc/xray/domain)
Login=$(cat /etc/xray/username)
nama=$(cat /etc/xray/username)
clear


# . Liner 
function baris_panjang() {
  echo -e "\033[5;36m ☉━━━━━━━━━━━━━━━━━━☉ \033[0m"
}

function Newbie_Banner() {
clear
baris_panjang
echo -e "\033[95;1m     $nama       \033[0m"
baris_panjang
}


function Sc_Credit(){
sleep 1
baris_panjang
echo -e "\033[2;35m      Terimakasih Telah Menggunakan \033[0m"
echo -e "\033[2;35m             Script Credit \033[0m"
echo -e "\033[2;35m           $nama  \033[0m"
baris_panjang
systemctl restart xray > /dev/null 2>&1
service cron restart > /dev/null 2>&1
exit 1
}

# // jalankan perintah :  sleep 3 & loading $!
loading() {
  local pid=$1
  local delay=0.1
  local spin='-\|/'

  while ps -p $pid > /dev/null; do
    local temp=${spin#?}
    printf "[%c] " "$spin"
    local spin=$temp${spin%"$temp"}
    sleep $delay
    printf "\b\b\b\b\b\b"
  done

  printf "    \b\b\b\b"
}
function BANNER() {
clear
baris_panjang
echo -e "\033[95;1m     XRAY VMESS    \033[0m"
baris_panjang
}



#tls="$(cat ~/log-install.txt | grep -w "Vmess TLS" | cut -d: -f2|sed 's/ //g')"
#none="$(cat ~/log-install.txt | grep -w "Vmess None TLS" | cut -d: -f2|sed 's/ //g')"
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do





# // Create Title account
Newbie_Banner
baris_panjang
BANNER
  echo -e " \033[37mJust input a number for-\033[0m"
  echo -e " \033[32mQuota Limit\033[0m"
  echo -e " \033[32mLimit IP\033[0m"
  echo -e " \033[37mFormat GB\033[0m"
echo ""
  echo -e " \033[33m0\033[0m \033[37mfor Unlimited\033[0m"
  echo -e " \033[33m0\033[0m \033[37Mfor No Limit\033[0m"
echo ""
baris_panjang
echo ""
read -rp " Username         : " -e user
		CLIENT_EXISTS=$(grep -w $user /etc/xray/config.json | wc -l)

		if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
Newbie_Banner         
baris_panjang
			echo ""
			echo -e "\033;91m Name Salah \033[0m "
			echo ""
baris_panjang
Sc_Credit
		fi
	done
ISP=$(cat /etc/xray/isp)
CITY=$(cat /etc/xray/city)
uuid=$(cat /proc/sys/kernel/random/uuid)
echo
read -p " Limit User (GB)  : " Quota
echo
read -p " Limit User (IP)  : " iplimit
echo
read -p " Expired (days)   : " masaaktif
echo
sleep 3 & loading $!





tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tgl2=$(date +"%d")
bln2=$(date +"%b")
thn2=$(date +"%Y")
tnggl="$tgl2 $bln2, $thn2"
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#vmess$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/config.json
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#vmessgrpc$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/config.json

asu=`cat<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "443",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/vmess",
      "type": "none",
      "host": "${domain}",
      "tls": "tls"
}
EOF`
ask=`cat<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "80",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/vmess",
      "type": "none",
      "host": "${domain}",
      "tls": "none"
}
EOF`
grpc=`cat<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "443",
      "id": "${uuid}",
      "aid": "0",
      "net": "grpc",
      "path": "vmess-grpc",
      "type": "none",
      "host": "${domain}",
      "tls": "tls"
}
EOF`
vmess_base641=$( base64 -w 0 <<< $vmess_json1)
vmess_base642=$( base64 -w 0 <<< $vmess_json2)
vmess_base643=$( base64 -w 0 <<< $vmess_json3)
vmesslink1="vmess://$(echo $asu | base64 -w 0)"
vmesslink2="vmess://$(echo $ask | base64 -w 0)"
vmesslink3="vmess://$(echo $grpc | base64 -w 0)"


cat >/var/www/html/vmess-$user.txt <<-END

======================
$nama
======================
# Format Vmess WS TLS

- name: Vmess-$user-WS TLS
  type: vmess
  server: ${domain}
  port: 443
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

# Format Vmess WS Non TLS

- name: Vmess-$user-WS Non TLS
  type: vmess
  server: ${domain}
  port: 80
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: false
  skip-cert-verify: false
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

# Format Vmess gRPC

- name: Vmess-$user-gRPC (SNI)
  server: ${domain}
  port: 443
  type: vmess
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  network: grpc
  tls: true
  servername: ${domain}
  skip-cert-verify: true
  grpc-opts:
    grpc-service-name: vmess-grpc

======================
 Link Akun Vmess
======================
Link TLS         : 
${vmesslink1}
======================
Link none TLS    : 
${vmesslink2}
======================
Link GRPC        : 
${vmesslink3}
======================
Aktif Selama   : $masaaktif Hari
Dibuat Pada    : $tnggl
Berakhir Pada  : $expe
======================

END
if [ ! -e /etc/vmess ]; then
  mkdir -p /etc/vmess
fi

if [[ $iplimit -gt 0 ]]; then
mkdir -p /etc/kyt/limit/vmess/ip
echo -e "$iplimit" > /etc/kyt/limit/vmess/ip/$user
else
echo > /dev/null
fi

if [ -z ${Quota} ]; then
  Quota="0"
fi

c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))

if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/vmess/${user}
fi
DATADB=$(cat /etc/vmess/.vmess.db | grep "^###" | grep -w "${user}" | awk '{print $2}')
if [[ "${DATADB}" != '' ]]; then
	sed -i "/\b${user}\b/d" /etc/vmess/.vmess.db
	echo "### ${user} ${exp} ${uuid} ${Quota} ${iplimit}" >>/etc/vmess/.vmess.db
else
echo "### ${user} ${exp} ${uuid} ${Quota} ${iplimit}" >>/etc/vmess/.vmess.db
fi
clear

CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="<code>☉━━━━━━━━━━━━━━━━━☉</code>
<code>      🧿 𝗩𝗠𝗘𝗦𝗦 🧿</code>
<code>☉━━━━━━━━━━━━━━━━━☉</code>
𝗜𝗦𝗣: $ISP
𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻: $CITY
𝗥𝗲𝗺𝗮𝗿𝗸𝘀   : $user
𝗗𝗼𝗺𝗮𝗶𝗻    : <code>$domain</code>
𝗜𝗗        : <code>$uuid</code>
Limit Quota : ${Quota} GB
Limit Device : ${iplimit}
Port TLS  : 400-900
Port NTLS : 80, 8080, 8081-9999
alterId   : 0
Security  : auto
network   : ws or grpc
Path      : /Multi-Path
Dynamic   : https://bugmu.com/path
Name      : vmess-grpc
<code>☉━━━━━━━━━━━━━━━━━☉</code>
<code>𝗪𝗦 :</code> <code>$vmesslink2</code>
<code>☉━━━━━━━━━━━━━━━━━☉</code>
<code>𝗧𝗟𝗦 :</code> <code>$vmesslink2</code>
<code>☉━━━━━━━━━━━━━━━━━☉</code>
<code>𝗴𝗥𝗣𝗖 :</code> <code>$vmesslink3</code>
<code>☉━━━━━━━━━━━━━━━━━☉</code>
𝗟𝗶𝗻𝗸 𝗦𝗮𝘃𝗲 𝗔𝗰𝗰𝗼𝘂𝗻𝘁 : https://${domain}:81/vmess-$user.txt
<code>☉━━━━━━━━━━━━━━━━━☉</code>
Aktif Selama   : $masaaktif
Dibuat Pada    : $tnggl
Berakhir Pada : $expe
<code>☉━━━━━━━━━━━━━━━━━━☉</code>"

curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="<code>☉━━━━━━━━━━━━━━━━━━☉
  𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗦𝗨𝗖𝗖𝗘𝗦
☉━━━━━━━━━━━━━━━━━━☉
☉ 𝗔𝗞𝗨𝗡 : VMESS
☉ 𝗜𝗦𝗣: $ISP
☉ 𝗥𝗘𝗚𝗜𝗢𝗡 : $CITY
☉ 𝗖𝗢𝗡𝗙𝗜𝗚 : 
☉ 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘 : $user
☉ 𝗗𝗘𝗩𝗜𝗖𝗘 : $iplimit HP
☉ 𝗛𝗔𝗥𝗚𝗔 : 
☉ 𝗔𝗞𝗧𝗜𝗙 : $masaaktif HARI
☉ 𝗞𝗮𝗱𝗮𝗹𝘂𝘄𝗮𝗿𝘀𝗮 : $expe
☉━━━━━━━━━━━━━━━━━━☉
$nama </code>"
curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null


clear
function Details_Account() {
echo -e "\033[37m"
echo -e " VMESS XRAY "
echo -e ""
echo -e " Remarks       : ${user}"
echo -e " Domain        : ${domain}"
echo -e " User Quota    : ${Quota} GB"
echo -e " User Ip       : ${iplimit} IP"
echo -e " Port TLS      : 400,8443"
echo -e " port WS       : 80,8880,8080,2082"
echo -e " Key           : ${uuid}"
echo -e " Localtions    : $CITY"
echo -e " ISP           : $ISP"
echo -e " AlterId       : 0"
echo -e " Security      : auto"
echo -e " Network       : ws"
echo -e " Path          : /vmess"
echo -e " Dynamic Path  : yourbug/vmess"
echo -e " ServiceName   : vmess-grpc"
echo -e "\033[0m"
}


function Link_Json() {
baris_panjang
echo -e " Link TLS      : ${vmesslink1}"
baris_panjang
echo -e " Link WS       : ${vmesslink2}"
baris_panjang
echo -e " Link GRPC     : ${vmesslink3}"
baris_panjang
echo -e " OpenClash     : https://${domain}:81/vmess-$user.txt"
baris_panjang
}



function Details_Expiry() {
echo -e "\033[33m Expiry        : $masaaktif Day \033[0m"
baris_panjang
}



Newbie_Banner
Details_Account
Link_Json
Details_Expiry
Sc_Credit